# -*- coding: utf-8 -*-
import os, shutil, re, urllib2, unicodedata
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import json, random
import time, datetime

ADDON = xbmcaddon.Addon('script.skinrandom')
ADDONID = ADDON.getAddonInfo('id')
ADDONNAME = ADDON.getAddonInfo('name')
ADDONVERSION = ADDON.getAddonInfo('version')
LANGUAGE = ADDON.getLocalizedString
SETTING = ADDON.getSetting
SETSETTING = ADDON.setSetting

def log(txt, popup=False):
    if isinstance (txt,str):
        txt = txt.decode("utf-8")
    message = u'%s: %s' % (ADDONID, txt)
    xbmc.log(msg=message.encode("utf-8"), level=xbmc.LOGDEBUG)
    if popup == True:
        oDialog = xbmcgui.Dialog()
        oDialog.ok('skinRandom', message.encode("utf-8"))

class cSkin():
    def __init__ ( self ):

        self.skin = xbmc.getSkinDir()
        myskin = xbmcaddon.Addon(id=self.skin)
        self.path_dir = xbmc.translatePath(myskin.getAddonInfo('path') ).decode('utf-8')
        name = xbmc.translatePath(myskin.getAddonInfo('name') ).decode('utf-8')
        #C:\Program Files (x86)\Kodi\addons\skin.estuary
        self.realdir = os.path.join(xbmc.translatePath("special://home/"), 'addons' , self.skin).decode('utf-8')

        self.defaultfiles =  os.path.join( self.path_dir, 'colors', 'defaults.xml' ).decode('utf-8')

        self.randomfiles =  os.path.join( self.path_dir, 'colors', 'random.xml' ).decode('utf-8')

        self.time = datetime.datetime.now()

        self.timedelta = datetime.timedelta(seconds=float(SETTING('skinrandom_time')))

        self.variable = []
        self.colors = []

    def setting(self):
        #mise a zero des variables
        ADDON.setSetting('skinrandom_realdir', "false")
        ADDON.setSetting('skinrandom_defaultfiles', "false")
        ADDON.setSetting('skinrandom_randomfiles', "false")

        if os.path.exists(self.realdir):
            ADDON.setSetting('skinrandom_realdir', "true")
        if os.path.exists(self.defaultfiles):
            ADDON.setSetting('skinrandom_defaultfiles', "true")
        if os.path.exists(self.randomfiles):
            ADDON.setSetting('skinrandom_randomfiles', "true")


    def _random_exits(self):
        if os.path.exists(self.randomfiles):
            return True
        else: return False

    def _service(self):
        ADDON.setSetting('skinrandom_enable', "false")
        return True

    def _color(self, popup=False):
        if os.path.exists(self.randomfiles):
            self._create_variable()
            self._create_sheme()
            self._create_directories(False)
            if not xbmc.Player().isPlaying():
                xbmc.executebuiltin('ReloadSkin()')
            log("Changement de couleurs", popup)
        else:
            log("impossible d'acedder a random file", popup)
        return


    def _load_files(self):
        #ne fonctionne pas
        #if xbmcvfs.exists(self.path_dir):
        if os.path.exists(self.path_dir) and not os.path.exists(self.realdir):
            try:
                ok = shutil.copytree(self.path_dir,  self.realdir)
                log('Dossier Skin copier', True)
                return True
            except:
                log('Impossible de copie le dossier', True)
        elif os.path.exists(self.realdir):
            return True
        return False


    def _create_directories( self, popup=False):
        try:
            info = xbmcvfs.File(self.randomfiles, 'w')
            info.write('<?xml version="1.0" encoding="UTF-8"?>\n<colors>\n')

            for var, color in self.variable:
                info.write('<color name="%s">%s</color>\n' % (var,color))

            info.write('</colors>')
            info.close()
            log("create directory ok", popup)
        except:
            log("impossible", popup)

    def _create_variable( self ):
        info = xbmcvfs.File(self.defaultfiles)
        content = info.read()
        regex = r'<color name="(.+?)">(.+?)</color>'
        matches = re.findall(regex, content)

        for var, color in matches:
            if var not in ['white', 'grey', 'black', 'green', 'red' , 'yellow', 'blue']:
                variable = [var,color]
                self.variable.append(variable)

    def _create_sheme( self ):

        r = random.randint(0,255)
        g = random.randint(0,255)
        b = random.randint(0,255)
        count = len(self.variable)
        url = 'http://www.thecolorapi.com/scheme?rgb=%s,%s,%s&format=json&mode=analogic&count=%s' % (r, g, b, count)

        request = urllib2.Request(url)
        response = urllib2.urlopen(request)
        data = json.loads(response.read().decode('utf-8'))

        for i, e in enumerate(data['colors']):
            news_color = '%s%s' % (self.variable[i][1][0:2], str(e['hex']['clean']))
            self.variable[i][1] = news_color



if ( __name__ == "__main__" ):
    log('script version %s started' % ADDONVERSION)
    Main()
log('script stopped')
