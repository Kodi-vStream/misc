# -*- coding: utf-8 -*-
from resources.lib.skin import cSkin

import xbmc, xbmcaddon
import time, datetime

ADDON = xbmcaddon.Addon('script.skinrandom')
ADDONID = ADDON.getAddonInfo('id')
ADDONNAME = ADDON.getAddonInfo('name')
ADDONVERSION = ADDON.getAddonInfo('version')
LANGUAGE = ADDON.getLocalizedString
SETTING = ADDON.getSetting
SETSETTING = ADDON.setSetting

def log(txt, popup=False):
    if isinstance (txt,str):
        txt = txt.decode("utf-8")
    message = u'%s: %s' % (ADDONID, txt)
    xbmc.log(msg=message.encode("utf-8"), level=xbmc.LOGDEBUG)
    if popup == True:
        oDialog = xbmcgui.Dialog()
        oDialog.ok('skinRandom', message.encode("utf-8"))

class Main():
    def __init__ ( self ):
        ok = cSkin()._random_exits()
        if ok:
            self.time = datetime.datetime.now()
            self.timedelta = datetime.timedelta(seconds=float(SETTING('skinrandom_time')))
            self.run()



    def run(self):
        if SETTING('skinrandom_enable') == "true":
            kodimonitor = xbmc.Monitor()
            #delta(weeks=40, days=84, hours=23,
            while not kodimonitor.abortRequested():

                if SETTING('skinrandom_enable') == "false":
                    break

                if (datetime.datetime.now() - self.time) >= self.timedelta:
                    cSkin()._color(False)
                    self.time = datetime.datetime.now()

                kodimonitor.waitForAbort(10)


if ( __name__ == "__main__" ):
    log('script version %s started' % ADDONVERSION)
    Main()
log('script stopped')
