# -*- coding: utf-8 -*-
from resources.lib.skin import cSkin

import xbmcaddon
import sys

ADDON = xbmcaddon.Addon('script.skinrandom')
ADDONID = ADDON.getAddonInfo('id')
ADDONNAME = ADDON.getAddonInfo('name')
ADDONVERSION = ADDON.getAddonInfo('version')
LANGUAGE = ADDON.getLocalizedString
SETTING = ADDON.getSetting

#executer en cliquant sur l'iconne
class Main:
    def __init__ ( self ):
        if len (sys.argv) != 2 :
            cSkin().setting()
            ADDON.openSettings()
        elif sys.argv[1] == "color":
            print cSkin()._color(True)
        elif sys.argv[1] == "folder":
            print cSkin()._load_files()
        elif sys.argv[1] == "random":
            print cSkin()._create_directories(True)
        elif sys.argv[1] == "service":
            print cSkin()._service()


if ( __name__ == "__main__" ):
    Main()
